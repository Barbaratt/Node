const express = require("express");
const cors = require("cors");

const { uuid } = require("uuidv4");

const app = express();

app.use(express.json());
app.use(cors());

const repositories = [];

app.get("/repositories", (request, response) => {
    return response.json(repositories);
  //o get serve para puxar os dados, por isso só precisa do return, pra puxar e dar os dados
});

app.post("/repositories", (request, response) => {
    const { id,title,techs } = request.body;
    const newRepository = {
        id: "uuid"(),
        title,
        url,
        techs,
        likes: 0

    }

    repositories.push(newRepository);
    return response.json(newRepository);
});

app.put("/repositories/:id", (request, response) => {
  const { id,title,techs } = request.body;
  const { id } = request.params;
  
  const repositoryIndex = repositories.findIndex(repository => repository.id === id);
  if (repositoryIndex < 0) {
    return response.status(400)json('Repository não encontrado');
      //Caso não seja possível mostrar o repositório, Irá mostrar o erro 400, Bad Request
  } 

  //Não precisa de um else aqui ?
    repositories [repositoryIndex = {
      id,
      title: title ? title:repositories[repositoryIndex].title,
      url: url ? url:repositories[repositoryIndex].url,
      techs: techs ? techs:repositories[repositoryIndex].techs,
      likes: repositories [repositoryIndex].likes
      //para que serve o ? para identificar o que é ?
    }]
    
    return response.json(repositories [repositoryIndex]);
});

app.delete("/repositories/:id", (request, response) => {
    const {id} = request.params;
    const repositoryIndex = repositories.findIndex(repositories => repository.id === id);

    if (repositoryIndex < 0) {

      {
        return response.status(400).json('Repository não encontrado');

      }

        repositories.splice(repositoryIndex, 1);
        return response.status(204).send(' ');
    }
});

app.post("/repositories/:id/like", (request, response) => {
  const {id} = request.params;
  const repositoryIndex = repositories.findIndex(repositories => repository.id === id);

  if (repositoryIndex < 0) {

    {
      return response.status(400).json('Repository não encontrado');

    }

    repositories[repositoryIndex].likes += 1;
    
    return response.json(repositories[repositoryIndex]);


};

module.exports = app;
